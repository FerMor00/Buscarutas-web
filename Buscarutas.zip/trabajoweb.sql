-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-01-2021 a las 12:51:25
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `trabajoweb`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios`
--

CREATE TABLE `comentarios` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `fecha` varchar(50) NOT NULL,
  `texto` varchar(250) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `comentarios`
--

INSERT INTO `comentarios` (`id`, `username`, `fecha`, `texto`, `trn_date`) VALUES
(1, '123', '2021-01-30 19:26:53', '', '0000-00-00 00:00:00'),
(2, '123', '2021-01-30 19:27:18', '', '0000-00-00 00:00:00'),
(3, '123', '2021-01-30 19:27:23', '', '0000-00-00 00:00:00'),
(4, '123', '2021-01-30 19:27:46', '123123123', '0000-00-00 00:00:00'),
(5, '123', '2021-01-31 11:09:56', 'qwyatuwratcuawdcyawd', '0000-00-00 00:00:00'),
(6, 'prueba', '2021-01-31 11:22:09', 'Muy agradable.', '0000-00-00 00:00:00'),
(7, 'prueba', '2021-01-31 11:22:38', 'Muy bonito.', '0000-00-00 00:00:00'),
(8, 'video', '2021-01-31 11:40:25', 'Increible.', '0000-00-00 00:00:00'),
(9, 'video', '2021-01-31 11:43:08', 'bonito', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `body` varchar(250) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacto`
--

CREATE TABLE `contacto` (
  `id` int(11) NOT NULL,
  `trn_date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `texto` varchar(500) NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `contacto`
--

INSERT INTO `contacto` (`id`, `trn_date`, `name`, `email`, `texto`, `submittedby`) VALUES
(1, '2021-01-30 12:44:59', 'Alberto', '123@gmail.com', 'wavdouawdcuawcudawvduawdvuawdcvawudcvuawcvducvasoudvouawvdouyasvcouyvasoucyvausvdawvduvaxoudvsaucvduavdlusvuacwud', '123'),
(2, '2021-01-30 12:46:35', 'Alberto', '123@gmail.com', 'qwte', '123'),
(3, '2021-01-30 12:46:49', 'Alberto', '123@gmail.com', 'qwte23', '123'),
(4, '2021-01-30 16:09:44', 'Alebrto', '123@gmail.com', '1234', '123'),
(5, '2021-01-31 11:09:25', '123', '123@gmail.com', 'qwyatuwratcuawdcyawd', '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `BODY` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `replies`
--

CREATE TABLE `replies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `body` varchar(250) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva`
--

CREATE TABLE `reserva` (
  `id` int(11) NOT NULL,
  `trn_date` datetime NOT NULL,
  `name` varchar(50) NOT NULL,
  `numero` int(11) NOT NULL,
  `fecha_reserva` int(11) NOT NULL,
  `submittedby` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `reserva`
--

INSERT INTO `reserva` (`id`, `trn_date`, `name`, `numero`, `fecha_reserva`, `submittedby`) VALUES
(1, '2021-01-30 12:57:30', 'Alberto', 10, 0, '123'),
(2, '2021-01-30 12:57:58', 'Alberto', 10, 12, '123'),
(3, '2021-01-30 16:08:47', 'Alberto', 2, 12, '123'),
(4, '2021-01-30 19:49:40', '123', 2, 12, '123'),
(5, '2021-01-30 19:51:33', '12', 12, 2021, '123'),
(6, '2021-01-31 11:09:02', '123', 12, 2021, '123'),
(7, '2021-01-31 11:21:15', 'Prueba', 3, 2021, 'prueba'),
(8, '2021-01-31 11:44:19', 'video', 5, 2021, 'video');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reserva_alhambra`
--

CREATE TABLE `reserva_alhambra` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `numero` int(3) NOT NULL,
  `fecha` date NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `trn_date`) VALUES
(1, 'qwerty', '123@gmail.com', '202cb962ac59075b964b07152d234b70', '2021-01-10 11:53:14'),
(2, '123', '12@gmail.com', '202cb962ac59075b964b07152d234b70', '2021-01-19 11:54:25'),
(3, 'prueba', 'prueba@gmail.com', 'c893bad68927b457dbed39460e6afd62', '2021-01-31 11:17:21'),
(4, 'video', 'video@gmail.com', '202cb962ac59075b964b07152d234b70', '2021-01-31 11:38:45');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `contacto`
--
ALTER TABLE `contacto`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD UNIQUE KEY `BODY` (`BODY`);

--
-- Indices de la tabla `replies`
--
ALTER TABLE `replies`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reserva`
--
ALTER TABLE `reserva`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `reserva_alhambra`
--
ALTER TABLE `reserva_alhambra`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `comentarios`
--
ALTER TABLE `comentarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `contacto`
--
ALTER TABLE `contacto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `replies`
--
ALTER TABLE `replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `reserva`
--
ALTER TABLE `reserva`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `reserva_alhambra`
--
ALTER TABLE `reserva_alhambra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

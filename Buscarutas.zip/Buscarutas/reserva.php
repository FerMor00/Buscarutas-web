<?php
    require('db.php');
    include("auth.php");
    $status = "";
    if(isset($_POST['new']) && $_POST['new']==1){
        $trn_date = date("Y-m-d H:i:s");
        $name = $_REQUEST['name'];
        $numero = $_REQUEST['numero'];
        $fecha_reserva = date("Y-m-d H:i:s");
        $submittedby = $_SESSION["username"];
        $ins_query="insert into reserva
        (`trn_date`,`name`,`numero`,`fecha_reserva`,`submittedby`)values
        ('$trn_date','$name','$numero','$fecha_reserva','$submittedby')";
        //mysqli_query($con,$insertar) or die ("Problemas al insertar".mysqli_error($con));
        mysqli_query($con,$ins_query)or die(mysqli_error($con));
        $status = "Reserva realizada.";
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Reserva</title>
    <link rel="stylesheet" href="css/estilologin.css" />
</head>
<body>
    <div class="form">
        <p><a href="proyecto_final.html">Página Principal</a></p>
        <div>
            <h1>Generar nueva reserva</h1>
            <form name="form" method="post" action=""> 
                <input type="hidden" name="new" value="1" />
                <p><input type="text" name="name" placeholder="Nombre" required /></p>
                <p><input type="int" name="numero" placeholder="Número de personas" required /></p>
                <p><input type="text" name="fecha_reserva" placeholder="Fecha de asistencia" required /></p>
                <p><input name="submit" type="submit" value="Submit" /></p>
            </form>
            <p style="color:#FF0000;"><?php echo $status; ?></p>
        </div>
    </div>
</body>
</html>
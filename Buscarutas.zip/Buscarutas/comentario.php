<?php
    require('db.php');
    include("auth.php");
    $status = "";
    if(isset($_POST['new']) && $_POST['new']==1){
        $fecha = date("Y-m-d H:i:s");
        $texto = $_REQUEST["texto"];
        $username = $_SESSION["username"];
        $ins_query="insert into comentarios
        (`fecha`,`texto`,`username`)values
        ('$fecha','$texto','$username')";
        //mysqli_query($con,$insertar) or die ("Problemas al insertar".mysqli_error($con));
        mysqli_query($con,$ins_query)or die(mysqli_error($con));
        $status = "Enviado correctamente.";
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Comentario</title>
    <link rel="stylesheet" href="css/estilologin.css" />
</head>
<body>
    <div class="form">
        <p><a href="proyecto_final.html">Página Principal</a></p>
        <div>
            <h1>¿Qué tal tu experiencia?</h1>
            <form name="form" method="post" action=""> 
                <input type="hidden" name="new" value="1" />
                <p><input type="date" name="fecha" placeholder="Fecha" required /></p>
                <p><input type="text" name="texto" placeholder="Comentario" required /></p>
                <p><input name="submit" type="submit" value="Submit" /></p>
            </form>
            <p style="color:#FF0000;"><?php echo $status; ?></p>
        </div>
    </div>
</body>
</html>
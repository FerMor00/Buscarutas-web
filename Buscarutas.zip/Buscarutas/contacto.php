<?php
    require('db.php');
    include("auth.php");
    $status = "";
    if(isset($_POST['new']) && $_POST['new']==1){
        $trn_date = date("Y-m-d H:i:s");
        $name = $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $texto = $_REQUEST['texto'];
        $submittedby = $_SESSION["username"];
        $ins_query="insert into contacto
        (`trn_date`,`name`,`email`,`texto`,`submittedby`)values
        ('$trn_date','$name','$email','$texto','$submittedby')";
        //mysqli_query($con,$insertar) or die ("Problemas al insertar".mysqli_error($con));
        mysqli_query($con,$ins_query)or die(mysqli_error($con));
        $status = "Enviado correctamente.";
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Contacta con nosotros</title>
    <link rel="stylesheet" href="css/estilologin.css" />
</head>
<body>
    <div class="form">
        <p><a href="proyecto_final.html">Página Principal</a></p>
        <div>
            <h1>Contacta con nosotros</h1>
            <form name="form" method="post" action=""> 
                <input type="hidden" name="new" value="1" />
                <p><input type="text" name="name" placeholder="Nombre" required /></p>
                <p><input type="text" name="email" placeholder="Email" required /></p>
                <p><input type="text" name="texto" placeholder="¿Qué nos quieres comentar?" required /></p>
                <p><input name="submit" type="submit" value="Submit" /></p>
            </form>
            <p style="color:#FF0000;"><?php echo $status; ?></p>
        </div>
    </div>
</body>
</html>
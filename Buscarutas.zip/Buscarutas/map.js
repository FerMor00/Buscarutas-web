// Javier Sánchez Soriano. Desarrollo Web y de Apps. 2020

// variables globales...
var marker;
var map;
var markers = []; // vamos a guardar los marcadores 

$( document ).ready(function() {
	inicializarMapa();
 
	// Manejadores de eventos
	//  Latitud / longitud
	$( "#Latitud" ).change(function() {
		centrar();
	});	
	$( "#Longitud" ).change(function() {
		centrar();
	});
	
	// Botón Guardar
	$( "#Guardar" ).click(function() {
		guardar();
	});
});

function inicializarMapa() {

    var latlngs = [ [38.91,-77.07], [37.77, -79.43], [39.04, -85.2]];
    var polyline = L.polyline(latlngs, {color: 'red'});
    polyline.addTo(map)
	// Actualizamos los campos de las coordenadas del fomulario
	$("#Latitud").val(galicia.lat);
	$("#Longitud").val(galicia.lng);
	
	map = L.map('map').setView(latlngs, 15);
	
	L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

	

	
	marker.on('dragend', function(ev) {
		// Actualizamos los campos de las coordenadas del fomulario
		$("#Latitud").val(marker.getLatLng().lat);
		$("#Longitud").val(marker.getLatLng().lng);
		centrar();
	});
	
	
}

// Función para centrar el mapa en unas coordenadas
function centrar() {
// Recogemos la posición actual
latitud = $("#Latitud").val();
longitud = $("#Longitud").val();

// verificamos que son válidos
	if (isNaN(latitud)) {
		alert("Latitud incorrecta!");
	}
	else if (isNaN(longitud)) {
		alert("Longitud incorrecta!");
	}
	else {	// Todo OK!	
		pos= new L.LatLng(latitud, longitud);
		// centramos el mapa		
		map.panTo(pos);
		
		// Movemos el marcador
		marker.setLatLng(pos);
	}
}

//---------------------------------------------------------------------------


//-------------------------------------------------------------------------------------
// Generar un nuevo marcador, añadirlo a la colección, al mapa y a la tabla
function guardar() {
	// Recogemos la posición actual
	latitud = $("#Latitud").val();
	longitud = $("#Longitud").val();
		
		
	//---- Creamos marcador y añadimos al mapa ----//
	var LeafIcon = L.Icon.extend({
		options: {
		   iconSize:     [30, 30],
		   iconAnchor:   [15, 30],
		   popupAnchor:  [-3, -76]
		}
	});
	var greenIcon = new LeafIcon({
		iconUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/9e/Pin-location.png'
	})
	
	markerAux = L.marker(new L.LatLng(latitud, longitud), {icon: greenIcon});
	markerAux.addTo(map);
	//---- Creamos marcador y añadimos al mapa ----//
	
	
	// Lo guardamos en el array
	markers.push(markerAux); 
	
	// Refrescamos la tabla de marcadores
	repintarTabla();
}
	  
function repintarTabla() {
	// recuperamos la tabla y su TBODY
	tbody = $("#tbodymarcadores");
	// vaciamos el TBODY
	tbody.empty();
	// repintamos todo el TBODY sacando la información del array de marcadores
	for(i=0; i<markers.length; i++) {
		// Generamos condigo HTML de una fila
		fila =	"<tr>" +
					"<td>" + (i+1) + "</td>" +
					"<td>" + markers[i].getLatLng().lat + "</td>" +
					"<td>" + markers[i].getLatLng().lng	+ "</td>" +
					"<td>" + '<a href="#" onclick="verMarcador('+i+');"><span class="fas fa-search-location"></span></a> ' +
							 '<a href="#" onclick="borrarMarcador('+i+');"><span class="fas fa-trash"></a> ' +	"</td>" +
				"</tr>";
		// Añadimos la fila al tbody
		tbody.append(fila);
		
	}

}	

function verMarcador(posicion) {
	map.panTo(markers[posicion].getLatLng());
}

function borrarMarcador(posicion) {
	// Quitamos el marcador del mapa
	map.removeLayer(markers[posicion]);
	
	// Quitar el marcador del array
	markers.splice(posicion, 1);
	
	// repintar la tabla
	repintarTabla();
}




	 
	  
	  
	  
	  
	  
	  